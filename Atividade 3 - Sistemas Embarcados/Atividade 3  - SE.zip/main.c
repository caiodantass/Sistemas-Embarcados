#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

#define DELAY_MS 500
#define NUM_LEDS 4

#define LED1_GPIO GPIO_NUM_5
#define LED2_GPIO GPIO_NUM_6
#define LED3_GPIO GPIO_NUM_7
#define LED4_GPIO GPIO_NUM_8

const gpio_num_t led_pins[NUM_LEDS] = {LED1_GPIO, LED2_GPIO, LED3_GPIO, LED4_GPIO};

void init_leds(void) {
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << LED1_GPIO) | (1ULL << LED2_GPIO) | 
                       (1ULL << LED3_GPIO) | (1ULL << LED4_GPIO),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    
    gpio_config(&io_conf);

    for (int i = 0; i < NUM_LEDS; i++) {
        gpio_set_level(led_pins[i], 0);
    }
}

void set_led(int led_index, int state) {
    if (led_index >= 0 && led_index < NUM_LEDS) {
        gpio_set_level(led_pins[led_index], state);
    }
}

void set_all_leds(int state) {
    for (int i = 0; i < NUM_LEDS; i++) {
        gpio_set_level(led_pins[i], state);
    }
}

void display_binary_number(int number) {
    for (int i = 0; i < NUM_LEDS; i++) {
        int bit = (number >> i) & 0x01;
        gpio_set_level(led_pins[i], bit);
    }
}

void binary_counter_phase(void) {
    printf("Iniciando Fase 1: Contador Binário\n");
    
    for (int count = 0; count < 16; count++) {
        printf("Contador binário: %d (", count);
        display_binary_number(count);

        for (int i = NUM_LEDS - 1; i >= 0; i--) {
            printf("%d", gpio_get_level(led_pins[i]));
        }
        printf(") - LEDs: ");

        for (int i = 0; i < NUM_LEDS; i++) {
            if (gpio_get_level(led_pins[i])) {
                printf("LED%d ", i + 1);
            }
        }
        printf("\n");
        
        vTaskDelay(DELAY_MS / portTICK_PERIOD_MS);
    }

    set_all_leds(0);
    vTaskDelay(DELAY_MS / portTICK_PERIOD_MS);
}

void sweep_sequence_phase(void) {
    printf("Iniciando Fase 2: Sequência de Varredura\n");

    printf("Varredura para frente:\n");
    for (int i = 0; i < NUM_LEDS; i++) {
        set_all_leds(0);  
        set_led(i, 1);    
        printf("GPIO %d (LED %d) aceso\n", led_pins[i], i + 1);
        vTaskDelay(DELAY_MS / portTICK_PERIOD_MS);
    }

    printf("Varredura para trás:\n");
    for (int i = NUM_LEDS - 1; i >= 0; i--) {
        set_all_leds(0);  
        set_led(i, 1);    
        printf("GPIO %d (LED %d) aceso\n", led_pins[i], i + 1);
        vTaskDelay(DELAY_MS / portTICK_PERIOD_MS);
    }

    set_all_leds(0);
}

void app_main(void) {
    printf("=== Iniciando Sistema de Controle de LEDs ===\n");
    printf("Configuração:\n");
    printf("- Delay: %d ms\n", DELAY_MS);
    printf("- LEDs: GPIO%d (LED1), GPIO%d (LED2), GPIO%d (LED3), GPIO%d (LED4)\n", 
           LED1_GPIO, LED2_GPIO, LED3_GPIO, LED4_GPIO);
    printf("- Resistores: 330Ω\n");

    init_leds();
    printf("LEDs inicializados e apagados\n");
    
    vTaskDelay(1000 / portTICK_PERIOD_MS); 

    while (1) {
        printf("\n--- Executando Fase 1: Contador Binário ---\n");
        binary_counter_phase();
        
        printf("\n--- Executando Fase 2: Sequência de Varredura ---\n");
        sweep_sequence_phase();
        
        printf("\n--- Ciclo completo. Reiniciando em 1 segundo... ---\n");
        vTaskDelay(1000 / portTICK_PERIOD_MS); 
    }
}